import AllNGOS from "./AllNGOS";

export default AllNGOS;