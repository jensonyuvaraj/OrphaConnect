import FoodDetails from "./FoodDetails";

export default FoodDetails;