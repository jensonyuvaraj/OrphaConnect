import React from 'react';
import spot from '../../Images/Spot add.png'
function Roles(){
    return (
        <div>
          <img src={spot} />
        </div>
    )
}

export default Roles;