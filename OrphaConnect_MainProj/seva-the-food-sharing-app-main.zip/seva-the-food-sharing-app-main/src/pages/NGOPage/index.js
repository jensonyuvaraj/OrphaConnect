import NGOPage from "./NGOPage";

export default NGOPage;