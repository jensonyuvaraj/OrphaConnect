import First from "../../Images/First.png";
import Second from "../../Images/Second.png";
import Third from "../../Images/Third.png";
export default [{
    title: 'Donate Effortlessly1',
    description: 'Donate From your comfert1',
    urls: First,
},
{
    title: 'Donate Effortlessly11',
    description: 'Donate From your comfert2',
    urls: Second,
},
{
    title: 'Donate Effortlessly123',
    description: 'Donate From your comfert222',
    urls: Third,
},
]