import ConfirmFoodDetails from "./ConfirmFoodDetails";

export default ConfirmFoodDetails;