import BottomNavbar from "./BottomNavbar";

export default BottomNavbar;