import NGOCard from "./NGOCard";

export default NGOCard;